<?php
/*
Plugin Name: dh akademie groups
Plugin URI: https://digitalehelden.de/
Description: Digitalehelden akademie groups
Author: Frank Mueller <set@cooki.me>
Author URI: https://github.com/setcooki/
Text Domain: dh-plugin
Version: 0.0.0
*/

if(!defined('DH_PLUGIN_DOMAIN'))
{
    define('DH_PLUGIN_DOMAIN', 'dh-plugin');
}

if(!function_exists('dh_akademie_groups'))
{
    function dh_akademie_groups()
    {
        
    }
}
dh_akademie_groups();
