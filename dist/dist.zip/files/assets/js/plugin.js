(function ($) {

    let plugin = {
        init: function () {
            $(document).ready(function () {

            });
        }
    };

    plugin.init();

})(jQuery.noConflict());
